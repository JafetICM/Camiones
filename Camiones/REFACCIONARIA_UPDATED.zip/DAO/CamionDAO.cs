
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Configuration;
using Refaccionaria.Models;

namespace Refaccionaria.DAO
{
    public class CamionDAO
    {
        private string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

        public Camion[] ObtenerCamiones()
        {
            List<Camion> listaCamiones = new List<Camion>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Camion";
                SqlCommand command = new SqlCommand(query, connection);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Camion camion = new Camion
                    {
                        IdCamion = (int)reader["IdCamion"],
                        Nombre = reader["Nombre"].ToString(),
                        TotalAlmacenaje = (decimal)reader["TotalAlmacenaje"],
                        Placas = reader["Placas"].ToString(),
                        Marca = reader["Marca"].ToString()
                    };

                    listaCamiones.Add(camion);
                }
            }

            return listaCamiones.ToArray();
        }
    }
}
