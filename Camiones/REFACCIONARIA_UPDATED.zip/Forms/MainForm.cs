
using System;
using System.Windows.Forms;
using Refaccionaria.DAO;
using Refaccionaria.Services;

namespace Refaccionaria.Forms
{
    public partial class MainForm : Form
    {
        private ServicioCamiones servicioCamiones;

        public MainForm()
        {
            InitializeComponent();
            CargarDatos();
        }

        private void CargarDatos()
        {
            CamionDAO camionDAO = new CamionDAO();
            var camiones = camionDAO.ObtenerCamiones();
            servicioCamiones = new ServicioCamiones(camiones);
            dataGridViewCamiones.DataSource = camiones;
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string criterio = txtBuscar.Text;
            var resultados = servicioCamiones.BuscarPorNombre(criterio);
            dataGridViewCamiones.DataSource = resultados;
        }
    }
}
