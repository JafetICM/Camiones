
namespace Refaccionaria.Forms
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView dataGridViewCamiones;
        private System.Windows.Forms.TextBox txtBuscar;
        private System.Windows.Forms.Button btnBuscar;

        private void InitializeComponent()
        {
            this.dataGridViewCamiones = new System.Windows.Forms.DataGridView();
            this.txtBuscar = new System.Windows.Forms.TextBox();
            this.btnBuscar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCamiones)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewCamiones
            // 
            this.dataGridViewCamiones.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCamiones.Location = new System.Drawing.Point(12, 58);
            this.dataGridViewCamiones.Name = "dataGridViewCamiones";
            this.dataGridViewCamiones.Size = new System.Drawing.Size(776, 380);
            this.dataGridViewCamiones.TabIndex = 0;
            // 
            // txtBuscar
            // 
            this.txtBuscar.Location = new System.Drawing.Point(12, 12);
            this.txtBuscar.Name = "txtBuscar";
            this.txtBuscar.Size = new System.Drawing.Size(657, 20);
            this.txtBuscar.TabIndex = 1;
            // 
            // btnBuscar
            // 
            this.btnBuscar.Location = new System.Drawing.Point(675, 10);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(113, 23);
            this.btnBuscar.TabIndex = 2;
            this.btnBuscar.Text = "Buscar";
            this.btnBuscar.UseVisualStyleBackColor = true;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // MainForm
            // 
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnBuscar);
            this.Controls.Add(this.txtBuscar);
            this.Controls.Add(this.dataGridViewCamiones);
            this.Name = "MainForm";
            this.Text = "Gestión de Camiones";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCamiones)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
