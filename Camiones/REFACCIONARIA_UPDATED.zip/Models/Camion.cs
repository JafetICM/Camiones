
namespace Refaccionaria.Models
{
    public class Camion
    {
        public int IdCamion { get; set; }
        public string Nombre { get; set; }
        public decimal TotalAlmacenaje { get; set; }
        public string Placas { get; set; }
        public string Marca { get; set; }
    }
}
